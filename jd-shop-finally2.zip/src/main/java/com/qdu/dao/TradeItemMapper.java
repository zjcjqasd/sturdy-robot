package com.qdu.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.qdu.bean.TradeItem;
import com.qdu.bean.TradeItemExample;

public interface TradeItemMapper {
    long countByExample(TradeItemExample example);

    int deleteByExample(TradeItemExample example);

    int deleteByPrimaryKey(Integer itemid);

    int insert(TradeItem record);

    int insertSelective(TradeItem record);

    List<TradeItem> selectByExample(TradeItemExample example);

    TradeItem selectByPrimaryKey(Integer itemid);

    int updateByExampleSelective(@Param("record") TradeItem record, @Param("example") TradeItemExample example);

    int updateByExample(@Param("record") TradeItem record, @Param("example") TradeItemExample example);

    int updateByPrimaryKeySelective(TradeItem record);

    int updateByPrimaryKey(TradeItem record);
}