package com.qdu.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qdu.bean.Goods;
import com.qdu.bean.Trade;
import com.qdu.dao.GoodsMapper;
import com.qdu.dao.TradeMapper;
import com.qdu.dao.UserLoginMapper;

@Service
public class GoodsService2
{
	@Autowired
	UserLoginMapper userLoginMapper;

	@Autowired
	GoodsMapper goodsMapper;

	/**
	 * 插入发布的商品，返回主键值
	 * 
	 * @param goods
	 */
	public Integer savePublish(Goods goods)
	{
		goodsMapper.insertSelective(goods);
		return goods.getGoodsid();
	}

	@Autowired
	TradeMapper tradeMapper;

	/**
	 * 插入一条交易记录
	 * 
	 * @param trade
	 */
	public void insert(Trade trade)
	{
		tradeMapper.insertSelective(trade);
		System.out.println(trade.getTradeid());
	}

}
