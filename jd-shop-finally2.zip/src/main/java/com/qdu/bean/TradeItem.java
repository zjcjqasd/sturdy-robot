package com.qdu.bean;

public class TradeItem {
    public TradeItem()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	private Integer itemid;

    private Integer goodsid;

    private Integer quantity;

    private Integer tradeid;

    public TradeItem(Integer itemid, Integer goodsid, Integer quantity, Integer tradeid)
	{
		super();
		this.itemid = itemid;
		this.goodsid = goodsid;
		this.quantity = quantity;
		this.tradeid = tradeid;
	}

	public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public Integer getGoodsid() {
        return goodsid;
    }

    public void setGoodsid(Integer goodsid) {
        this.goodsid = goodsid;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getTradeid() {
        return tradeid;
    }

    public void setTradeid(Integer tradeid) {
        this.tradeid = tradeid;
    }
}