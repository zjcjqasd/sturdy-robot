package com.qdu.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qdu.bean.TradeItem;
import com.qdu.dao.TradeItemMapper;

@Service
public class TradeItemService
{
	@Autowired
	TradeItemMapper tradeItemMapper;

	@Autowired
	SqlSession sqlSession;

	/**
	 * 批量保存交易记录
	 * 
	 * @param tradeItems
	 */
	public void batchSave(Collection<TradeItem> tradeItems)
	{
		List<TradeItem> tradeItems2 = new ArrayList(tradeItems);

		TradeItemMapper mapper = sqlSession.getMapper(TradeItemMapper.class);
		for (int i = 0; i < tradeItems2.size(); i++)
		{
			Integer goodsid = tradeItems2.get(i).getGoodsid();
			Integer quantity = tradeItems2.get(i).getQuantity();
			//mapper.insertSelective(new TradeItem(goodsid, quantity));
		}
	}

}
