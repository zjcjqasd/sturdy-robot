package com.qdu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qdu.bean.Goods;
import com.qdu.bean.UserLogin;
import com.qdu.bean.UserLoginExample;
import com.qdu.bean.UserLoginExample.Criteria;
import com.qdu.dao.GoodsMapper;
import com.qdu.dao.UserLoginMapper;

@Service
public class UserLoginService
{
	@Autowired
	UserLoginMapper userLoginMapper;

	@Autowired
	GoodsMapper goodsMapper;

	/**
	 * 检查用户名是否重复
	 * 
	 * @param username
	 * @return
	 */
	public Boolean checkUser(String username)
	{
		UserLoginExample example = new UserLoginExample();
		Criteria criteria = example.createCriteria();
		criteria.andUsernameEqualTo(username);
		long count = userLoginMapper.countByExample(example);
		return count == 0;
	}

	/**
	 * 保存注册的员工
	 * 
	 * @param userLogin
	 */
	public void saveEmp(UserLogin userLogin)
	{
		userLoginMapper.insertSelective(userLogin);
	}

	/**
	 * 验证用户名密码匹配
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	public Boolean checkUandP(String username, String password)
	{
		UserLoginExample example = new UserLoginExample();
		Criteria criteria = example.createCriteria();
		criteria.andUsernameEqualTo(username);
		List<UserLogin> userLogins = userLoginMapper.selectByExample(example);

		if (userLogins.isEmpty())
		{
			return false;
		}

		UserLogin userLogin = userLogins.get(0);
		String password2 = userLogin.getPassword();
		if (!password.equals(password2))
		{
			return false;
		}

		return true;
	}

	/**
	 * 根据用户名获取支付密码
	 * 
	 * @param username
	 * @return
	 */
	public UserLogin getUserByUserName(String username)
	{
		UserLoginExample example = new UserLoginExample();
		Criteria criteria = example.createCriteria();
		criteria.andUsernameEqualTo(username);
		List<UserLogin> userLogins = userLoginMapper.selectByExample(example);
		UserLogin userLogin = userLogins.get(0);
		return userLogin;
	}

	/**
	 * 根据商品id获取商品
	 * 
	 * @param goodsid
	 * @return
	 */
	public Goods getGood(Integer goodsid)
	{
		Goods good = goodsMapper.selectByPrimaryKey(goodsid);
		return good;
	}

	/**
	 * 根据username获取id
	 * 
	 * @return
	 */
	public Integer getId(String username)
	{
		UserLoginExample example = new UserLoginExample();
		Criteria criteria = example.createCriteria();
		criteria.andUsernameEqualTo(username);
		List<UserLogin> userLogins = userLoginMapper.selectByExample(example);
		UserLogin userLogin = userLogins.get(0);
		Integer id = userLogin.getId();
		return id;
	}


}
