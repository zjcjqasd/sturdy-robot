package com.qdu.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qdu.bean.Goods;
import com.qdu.bean.GoodsExample;
import com.qdu.bean.ShoppingCart;
import com.qdu.bean.ShoppingCartItem;
import com.qdu.bean.Trade;
import com.qdu.bean.GoodsExample.Criteria;
import com.qdu.dao.GoodsMapper;
import com.qdu.test.GoodsService2;

@Service
public class GoodsService {
	@Autowired
	GoodsMapper goodsMapper;

	@Autowired
	SqlSession sqlSession;

	@Autowired
	AccountService accountService;

	@Autowired
	TradeService tradeService;

	@Autowired
	GoodsService2 goodsService2;

	@Autowired
	UserLoginService userLoginService;

	@Autowired
	TradeItemService tradeItemService;

	/**
	 * 在页面上显示所有商品
	 * 
	 * @return
	 */
	public List<Goods> getAll() {
		GoodsExample example = new GoodsExample();
		example.setOrderByClause("goodsid DESC");
		List<Goods> goods = goodsMapper.selectByExample(example);
		return goods;
	}

	/**
	 * 模糊搜索
	 * 
	 * @return
	 */
	public List<Goods> getByPartName(String Partname) {
		String partname = "%" + Partname + "%";
		List<Goods> goods = goodsMapper.selectByPartname(partname);
		return goods;
	}

	/**
	 * 根据销量
	 * 
	 * @return
	 */
	public List<Goods> getGoodsBySales1(String Partname) {
		String partname = "%" + Partname + "%";
		List<Goods> goods = goodsMapper.selectByPartname(partname);
		return goods;
	}

	/**
	 * 根据价格高低
	 * 
	 * @return
	 */
	public List<Goods> getGoodsByPricea1(String Partname) {
		String partname = "%" + Partname + "%";
		List<Goods> goods = goodsMapper.selectByPartname(partname);
		return goods;
	}

	/**
	 * 根据价格迪高
	 * 
	 * @return
	 */
	public List<Goods> getGoodsByPriced1(String Partname) {
		String partname = "%" + Partname + "%";
		List<Goods> goods = goodsMapper.selectByPartname(partname);
		return goods;
//		GoodsExample example = new GoodsExample();
//		Criteria criteria = example.createCriteria();
//		String partname = "%" + Partname + "%";
//		criteria.andNameEqualTo(partname);
//		example.setOrderByClause("price Desc");
//		List<Goods> goods = goodsMapper.selectByExample(example);
//		return goods;
	}

	/**
	 * 获取单一商品
	 * 
	 * @param goodid
	 * @return
	 */
	public Goods getGood(Integer goodid) {
		Goods good = goodsMapper.selectByPrimaryKey(goodid);
		return good;
	}

	/**
	 * 加入购物车
	 * 
	 * @param goodid
	 * @param sc
	 */
	public void addToCart(Integer goodid, ShoppingCart sc) {
		Goods good = goodsMapper.selectByPrimaryKey(goodid);
		sc.addGood(good);
		// System.out.println(sc.getGoods());
	}

	/**
	 * 删除购物项
	 * 
	 * @param sc
	 * @param goodid
	 */
	public void removeItemFromShoppingCart(ShoppingCart sc, Integer goodid) {
		sc.removeItem(goodid);
	}

	/**
	 * 跟新商品数量
	 * 
	 * @param sc
	 * @param goodid
	 * @param quantityVal
	 */
	public void updateItemQuantity(ShoppingCart sc, Integer goodid, Integer quantityVal) {
		sc.updateItemQuantity(goodid, quantityVal);
	}

	/**
	 * 事务操作，更新数据库中数据
	 * 
	 * @param shoppingCart
	 * @param username
	 * @param paypwd
	 */
	@Transactional
	public void cash(ShoppingCart shoppingCart, String username, String paypwd) {
		// 1. 批量更新 goods 数据表相关记录的 salesamount 和 storenumber
		Collection<ShoppingCartItem> items = shoppingCart.getItems();
		List<ShoppingCartItem> scis = new ArrayList<ShoppingCartItem>(items);

		GoodsMapper mapper = sqlSession.getMapper(GoodsMapper.class);

		// 遍历每一项商品
		for (int i = 0; i < items.size(); i++) {
			// 获取到购买的数量,id
			int quantity = scis.get(i).getQuantity();
			Integer goodsid = scis.get(i).getGoods().getGoodsid();
			// 商品库存=原来库存-quantity————商品销量=原来销量+quantity
			Integer salesamount = scis.get(i).getGoods().getSalesamount();
			salesamount += quantity;
			Integer storenumber = scis.get(i).getGoods().getStorenumber();
			storenumber -= quantity;
			// 选择更新
			mapper.updateByPrimaryKeySelective(new Goods(goodsid, null, null, salesamount, storenumber, null));
		}

		// 2. 更新 account 数据表的 balance
		// 获取消费钱数
		int totalMoney = (int) shoppingCart.getTotalMoney();
		accountService.updateBalance(totalMoney, username);

		// 3. 向 trade 数据表插入一条记录
		Trade trade = new Trade();
		trade.setTradetime(new Date(new java.util.Date().getTime()));
		trade.setId(userLoginService.getId(username));
		goodsService2.insert(trade);

		// 4. 向 tradeitem 数据表插入 n 条记录
		// Collection<TradeItem> tradeItems = new ArrayList<>();
		// for (int i = 0; i < items.size(); i++)
		// {
		// TradeItem tradeItem = new TradeItem();
		//
		// tradeItem.setGoodsid(scis.get(i).getGoods().getGoodsid());
		// tradeItem.setQuantity(scis.get(i).getQuantity());
		//
		// tradeItems.add(tradeItem);
		// }
		// tradeItemService.batchSave(tradeItems);

		// 5. 清空购物车
		shoppingCart.clear();
	}

	/**
	 * 根据类型获取商品
	 * 
	 * @param type
	 * @return
	 */
	public List<Goods> getGoodsByType(String type) {
		GoodsExample example = new GoodsExample();
		Criteria criteria = example.createCriteria();
		criteria.andTypeEqualTo(type);
		example.setOrderByClause("goodsid DESC");
		List<Goods> goods = goodsMapper.selectByExample(example);
		return goods;
	}

	/**
	 * \ 查询出重要商品
	 * 
	 * @return
	 */
	public List<Goods> getImpGoods() {
		GoodsExample example = new GoodsExample();
		Criteria criteria = example.createCriteria();
		criteria.andImportantEqualTo(1);
		example.setOrderByClause("goodsid DESC");
		List<Goods> goods = goodsMapper.selectByExample(example);
		return goods;
	}

	/**
	 * 根据销量从大到小排列
	 * 
	 * @param type
	 * @return
	 */
	public List<Goods> getGoodsBySales(String type) {
		GoodsExample example = new GoodsExample();
		Criteria criteria = example.createCriteria();
		criteria.andTypeEqualTo(type);
		example.setOrderByClause("salesamount Desc");
		List<Goods> goods = goodsMapper.selectByExample(example);
		return goods;
	}

	/**
	 * 根据价格由高到低排列
	 * 
	 * @param type
	 * @return
	 */
	public List<Goods> getGoodsByPricea(String type) {
		GoodsExample example = new GoodsExample();
		Criteria criteria = example.createCriteria();
		criteria.andTypeEqualTo(type);
		example.setOrderByClause("price Desc");
		List<Goods> goods = goodsMapper.selectByExample(example);
		return goods;
	}

	/**
	 * 根据价格由低到高排列
	 * 
	 * @param type
	 * @return
	 */
	public List<Goods> getGoodsByPriced(String type) {
		GoodsExample example = new GoodsExample();
		Criteria criteria = example.createCriteria();
		criteria.andTypeEqualTo(type);
		example.setOrderByClause("price ASC");
		List<Goods> goods = goodsMapper.selectByExample(example);
		return goods;
	}

	/**
	 * 保存发布的商品
	 * 
	 * @param goods
	 */
	public void savePublish(Goods goods) {
		goodsMapper.insertSelective(goods);
		System.out.println(goods.getGoodsid());
	}

	/**
	 * 根据多条goodsid查询出goods集合
	 * 
	 * @param goodsids
	 * @return
	 */
	public List<Goods> getGoodsByGoodsids(List<Integer> goodsids) {
		List<Goods> goodsList = new ArrayList<Goods>();

		for (Integer goodsid : goodsids) {
			Goods goods = goodsMapper.selectByPrimaryKey(goodsid);
			goodsList.add(goods);
		}
		return goodsList;
	}

	/**
	 * 根据goodsid删除商品
	 * 
	 * @param goodsid
	 */
	public void delByGoodsid(Integer goodsid) {
		goodsMapper.deleteByPrimaryKey(goodsid);
	}

	public void delByGoodsid(String string) {
		goodsMapper.deleteByPrimaryKey(Integer.parseInt(string));
	}

	/**
	 * 修改商品
	 * 
	 * @param goodsid
	 * @param goods
	 */
	public void edit_goods(Integer goodsid, Goods goods) {
		GoodsExample example = new GoodsExample();
		Criteria createCriteria = example.createCriteria();
		createCriteria.andGoodsidEqualTo(goodsid);
		goodsMapper.updateByExampleSelective(goods, example);
	}

}
