package com.qdu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qdu.bean.Coupon;
import com.qdu.dao.CouponMapper;

@Service
public class CouponService {
	@Autowired
	CouponMapper couponMapper;

	public List<Coupon> getAll(Integer userid) {

		List<Coupon> coupon = couponMapper.selectByUser(userid);
		return coupon;
	}

	public void insert(Coupon coupon) {
		couponMapper.insertCoupon(coupon);

	}

}
