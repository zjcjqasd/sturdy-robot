package com.qdu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qdu.bean.Trade;
import com.qdu.bean.TradeExample;
import com.qdu.bean.TradeExample.Criteria;
import com.qdu.dao.TradeMapper;

@Service
public class TradeService
{
	@Autowired
	TradeMapper tradeMapper;

	/**
	 * 插入一条交易记录
	 * 
	 * @param trade
	 */
	public void insert(Trade trade)
	{
		tradeMapper.insertSelective(trade);
	}

}
