package com.atguigu.crud.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Account2;
//import com.atguigu.crud.bean.Coupon;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.ShoppingCart;
import com.atguigu.crud.bean.ShoppingCartItem;
import com.atguigu.crud.bean.UserLogin;
import com.atguigu.crud.service.AccountService;
//import com.atguigu.crud.service.CouponService;
import com.atguigu.crud.service.GoodsService;
import com.atguigu.crud.service.UserLoginService;
import com.atguigu.crud.utils.WebUtils;

@Controller
public class UserLoginController {
	@Autowired
	UserLoginService userLoginService;
//
//	@Autowired
//	CouponService CouponService;

	@Autowired
	AccountService accountService;

	@Autowired
	GoodsService goodsService;

	/**
	 * 结账操作
	 * 
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/pay")
	public Msg pay(String username, String paypwd, HttpServletRequest request, HttpSession session) {
		// 三重验证
		StringBuffer errors = validateUser(username, paypwd);
		if (errors.toString().equals("")) {
			errors = validateBookStoreNumber(session);
			if (errors.toString().equals("")) {
				errors = validateBalance(session, username);
			}
		}

		// 若验证不通过
		if (!errors.toString().equals("")) {
			return Msg.fail().add("errors", errors);
		} else {
			// 执行事务操作
			goodsService.cash(WebUtils.getShoppingCart(session), username, paypwd);
			return Msg.success();
		}

	}

//	/**
//	 * 结账操作
//	 * 
//	 * @return
//	 */
//	@ResponseBody
//	@RequestMapping("/getCoupon")
//	public void getCoupon(Integer userid, HttpSession httpSession) {
//
//		List<Coupon> coupons = CouponService.getAll(userid);
//		httpSession.setAttribute("couponslist", coupons);
//
//	}
//
//	/**
//	 * 结账操作
//	 * 
//	 * @return
//	 */
//	@ResponseBody
//	@RequestMapping("/setCoupon")
//	public void setCoupon(String Coupon, Integer Couponvalue, HttpSession httpSession) {
//
//		Integer userid = userLoginService.getId((String) httpSession.getAttribute("username"));
//		Coupon coupon = new Coupon(userid, Coupon, Couponvalue);
//		CouponService.insert(coupon);
//	}

	// 3.验证余额是否足够

	public StringBuffer validateBalance(HttpSession session, String username) {
		StringBuffer errors = new StringBuffer("");
		ShoppingCart sc = WebUtils.getShoppingCart(session);

		Account2 account = accountService.getAccount(username);
		if (sc.getTotalMoney() > account.getBalance()) {
			errors.append("您的余额不足！");
		}
		return errors;
	}

	// 2.验证库存是否充足
	public StringBuffer validateBookStoreNumber(HttpSession session) {
		StringBuffer errors = new StringBuffer("");
		ShoppingCart sc = WebUtils.getShoppingCart(session);

		for (ShoppingCartItem sci : sc.getItems()) {
			int quantity = sci.getQuantity();
			int storeNumber = userLoginService.getGood(sci.getGoods().getGoodsid()).getStorenumber();

			if (quantity > storeNumber) {
				errors.append("商品【" + sci.getGoods().getName() + "】的库存不足！");
			}
		}
		return errors;
	}

	// 1.检验用户名和支付密码是否匹配
	public StringBuffer validateUser(String username, String paypwd) {
		boolean flag = false;
		UserLogin userLogin = userLoginService.getUserByUserName(username);

		String paypwd2 = userLogin.getPaypwd();
		if (paypwd.trim().equals("" + paypwd2)) {
			flag = true;
		}

		StringBuffer errors2 = new StringBuffer("");
		if (!flag) {
			errors2.append("支付密码错误");
		}
		return errors2;
	}

	/**
	 * 退出登录
	 * 
	 * @param httpSession
	 * @return
	 */
	@RequestMapping("/logout")
	public String logout(HttpSession httpSession) {
		httpSession.invalidate();
		return "forward:/index.jsp";
	}

	/**
	 * 检验用户名和密码是否匹配
	 * 
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/checklogin")
	public Msg getEmp(@RequestParam("username") String username, @RequestParam("password") String password,
			HttpSession httpSession) {
		Boolean b = userLoginService.checkUandP(username, password);
		if (b) {
			httpSession.setAttribute("username", username);
			return Msg.success();
		} else {
			return Msg.fail();
		}
	}

	@ResponseBody
	@RequestMapping("/test")
	public String getTest() {
		return "This is test";
	}

	/**
	 * 注册保存员工
	 * 
	 * @param employee
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/emp", method = RequestMethod.POST)
	@ResponseBody
	public Msg saveEmp(UserLogin userLogin) {
		// 校验成功保存数据
		userLoginService.saveEmp(userLogin);

		// 获取username保存到account表中
		accountService.saveUsername(userLogin.getUsername());
		return Msg.success();
	}

	/**
	 * 检验用户名是否重复
	 * 
	 * @param username
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/checkuser")
	public Msg checkuser(@RequestParam("username") String username) {
		// 先验证用户名是否为合法表达式
		String regx = "(^[a-zA-Z0-9_-]{6,16}$)|(^[\u2E80-\u9FFF]{2,5})";
		if (!username.matches(regx)) {
			return Msg.fail().add("va_msg", "-用户名可以是2-5位中文或者6-16位英文和数字的组合");
		}
		// 验证用户名是否重复
		Boolean b = userLoginService.checkUser(username);
		if (b) {
			return Msg.success();
		} else {
			return Msg.fail().add("va_msg", "-用户名已存在");
		}
	}
}
