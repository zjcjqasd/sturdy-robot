package com.atguigu.crud.bean;

/**
 * 封装了商品以及商品的数量
 * 
 * @author 田永鑫
 *
 */
public class ShoppingCartItem
{
	private Goods goods;
	private int quantity;

	public Goods getGoods()
	{
		return goods;
	}

	public int getQuantity()
	{
		return quantity;
	}

	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}

	/**
	 * 返回一条购物项的钱数
	 * 
	 * @return
	 */
	public float getItemMoney()
	{
		return quantity * goods.getPrice();
	}

	public ShoppingCartItem(Goods goods)
	{
		super();
		this.goods = goods;
		this.quantity = 1;
	}

	public ShoppingCartItem()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 商品数量加一
	 */
	public void increment()
	{
		quantity++;
	}
}
