package com.atguigu.crud.utils;

import javax.servlet.http.HttpSession;

import com.atguigu.crud.bean.ShoppingCart;

public class WebUtils
{
	/**
	 * 获取购物车对象：从Session中获取，若session中没有该对象，
	 * 则创建一个新的ShoppingCart并放入Session中，若有，则直接返回
	 * 
	 * @return
	 */
	public static ShoppingCart getShoppingCart(HttpSession session)
	{
		ShoppingCart sc = (ShoppingCart) session.getAttribute("ShoppingCart");
		if (sc == null)
		{
			sc = new ShoppingCart();
			session.setAttribute("ShoppingCart", sc);
		}
		return sc;
	}
}
