package com.atguigu.crud.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Sales;
import com.atguigu.crud.bean.SalesExample;
import com.atguigu.crud.bean.SalesExample.Criteria;
import com.atguigu.crud.dao.SalesMapper;

@Service
public class SalesService
{
	@Autowired
	SalesMapper salesMapper;

	/**
	 * 插入发布的商品id
	 *
	 * @param id
	 * @param goodsid
	 */
	public void insert(Integer id, Integer goodsid)
	{
		salesMapper.insertSelective(new Sales(null, goodsid, id));
	}

	/**
	 * 得到商品id
	 * 
	 * @param id
	 * @return
	 */
	public List<Integer> getGoods(Integer id)
	{
		SalesExample example = new SalesExample();
		Criteria criteria = example.createCriteria();
		criteria.andIdEqualTo(id);
		List<Sales> sales = salesMapper.selectByExample(example);

		List<Integer> goodsids = new ArrayList<Integer>();

		for (Sales sales2 : sales)
		{
			Integer goodsid = sales2.getGoodsid();
			goodsids.add(goodsid);
		}
		return goodsids;
	}

	/**
	 * 根据goodsid删除sales表中数据
	 * 
	 * @param goodsid
	 */
	public void delByGoodsid(Integer goodsid)
	{
		SalesExample example = new SalesExample();
		Criteria criteria = example.createCriteria();
		criteria.andGoodsidEqualTo(goodsid);
		salesMapper.deleteByExample(example);
	}

	public void delByGoodsid(String trim)
	{
		SalesExample example = new SalesExample();
		Criteria criteria = example.createCriteria();
		criteria.andGoodsidEqualTo(Integer.parseInt(trim));
		salesMapper.deleteByExample(example);
	}

}
