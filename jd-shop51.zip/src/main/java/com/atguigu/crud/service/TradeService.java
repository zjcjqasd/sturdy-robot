package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Trade;
import com.atguigu.crud.bean.TradeExample;
import com.atguigu.crud.bean.TradeExample.Criteria;
import com.atguigu.crud.dao.TradeMapper;

@Service
public class TradeService
{
	@Autowired
	TradeMapper tradeMapper;

	/**
	 * 插入一条交易记录
	 * 
	 * @param trade
	 */
	public void insert(Trade trade)
	{
		tradeMapper.insertSelective(trade);
	}

}
