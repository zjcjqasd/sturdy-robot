package com.qdu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qdu.bean.Account2;
import com.qdu.dao.Account2Mapper;

@Service
public class AccountService
{
	@Autowired
	Account2Mapper account2Mapper;

	/**
	 * 根据支付密码查询账户余额
	 * 
	 * @param paypwd
	 * @return
	 */
	public Account2 getAccount(String username)
	{
		Account2 account = account2Mapper.selectByPrimaryKey(username);
		return account;
	}

	/**
	 * 更新余额
	 */
	public void updateBalance(int totalMoney, String username)
	{
		// 消费余额=现有钱数-消费钱数
		Account2 accout = account2Mapper.selectByPrimaryKey(username);
		Integer balance = accout.getBalance();
		balance -= totalMoney;
		// 更新balance
		account2Mapper.updateByPrimaryKeySelective(new Account2(username, balance));
	}

	/**
	 * 注册保存username到account表
	 * 
	 * @param username
	 */
	public void saveUsername(String username)
	{
		// 账户余额默认100
		account2Mapper.insert(new Account2(username, 100));
	}

}
