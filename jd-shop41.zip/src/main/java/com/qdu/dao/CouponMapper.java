package com.qdu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.qdu.bean.Coupon;
import com.qdu.bean.CouponExample;

public interface CouponMapper {
	long countByExample(CouponExample example);

	int deleteByExample(CouponExample example);

	int insert(Coupon record);

	int insertSelective(Coupon record);

	int insertCoupon(Coupon record);

	List<Coupon> selectByUser(Integer id);

	List<Coupon> selectByExample(CouponExample example);

	int updateByExampleSelective(@Param("record") Coupon record, @Param("example") CouponExample example);

	int updateByExample(@Param("record") Coupon record, @Param("example") CouponExample example);
}