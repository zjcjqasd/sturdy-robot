package com.qdu.bean;

public class Account2 {
    public Account2()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	private String username;

    private Integer balance;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public Integer getBalance() {
        return balance;
    }

    public Account2(String username, Integer balance)
	{
		super();
		this.username = username;
		this.balance = balance;
	}

	public void setBalance(Integer balance) {
        this.balance = balance;
    }
}