package com.qdu.bean;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ShoppingCart
{
	/**
	 * Map集合用于删除操作，键：书的id，值：ShoppingCartItem
	 */
	private Map<Integer, ShoppingCartItem> goods = new HashMap<Integer, ShoppingCartItem>();

	/**
	 * 修改id指定的商品项的数量
	 */
	public void updateItemQuantity(Integer id, int quantity)
	{
		ShoppingCartItem sci = goods.get(id);
		if (sci != null)
		{
			sci.setQuantity(quantity);
		}
	}

	/**
	 * 移除id指定的购物项
	 * 
	 * @param id
	 */
	public void removeItem(Integer id)
	{
		goods.remove(id);
	}

	/**
	 * 清空购物车
	 */
	public void clear()
	{
		goods.clear();
	}

	/**
	 * 购物车是否为空
	 * 
	 * @return
	 */
	public boolean isEmpty()
	{
		return goods.isEmpty();
	}

	/**
	 * 获取购物车中所有商品总钱数
	 * 
	 * @return
	 */
	public float getTotalMoney()
	{
		float total = 0;

		for (ShoppingCartItem sci : getItems())
		{
			total += sci.getItemMoney();
		}

		return total;
	}

	/**
	 * 获取购物车中所有ShoppingCartItem构成的集合
	 * 
	 * @return
	 */
	public Collection<ShoppingCartItem> getItems()
	{
		return goods.values();
	}

	/**
	 * 获取购物车中商品总数
	 * 
	 * @return
	 */
	public int getGoodsNumber()
	{
		int total = 0;

		for (ShoppingCartItem sci : goods.values())
		{
			total += sci.getQuantity();
		}

		return total;
	}

	public Map<Integer, ShoppingCartItem> getGoods()
	{
		return goods;
	}

	/**
	 * 检验购物车中是否有id指定的商品
	 */
	public boolean hasBook(Integer id)
	{
		return goods.containsKey(id);
	}

	/**
	 * 向购物车中添加一件商品
	 * 
	 * @param good
	 */
	public void addGood(Goods good)
	{
		// 检查购物车中有没有该商品，若有，则使其数量+1，若没有，新创建对应的ShoppingCartItem对象，并将其添加到books中
		ShoppingCartItem sci = goods.get(good.getGoodsid());
		if (sci == null)
		{
			sci = new ShoppingCartItem(good);
			goods.put(good.getGoodsid(), sci);
		} else
		{
			sci.increment();
		}
	}
}
