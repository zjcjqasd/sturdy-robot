package com.qdu.bean;

public class Coupon {

	private Integer couponid;

	private Integer userid;

	private String coupon;

	private Integer couponvalue;

	public Coupon(Integer couponid, Integer userid, String coupon, Integer couponvalue) {
		super();
		this.couponid = couponid;
		this.userid = userid;
		this.coupon = coupon;
		this.couponvalue = couponvalue;
	}

	public Coupon(Integer userid, String coupon, Integer couponvalue) {
		super();
		this.userid = userid;
		this.coupon = coupon;
		this.couponvalue = couponvalue;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon == null ? null : coupon.trim();
	}

	public Integer getCouponid() {
		return couponid;
	}

	public void setCouponid(Integer couponid) {
		this.couponid = couponid;
	}

	public Integer getCouponvalue() {
		return couponvalue;
	}

	public void setCouponvalue(Integer couponvalue) {
		this.couponvalue = couponvalue;
	}
}