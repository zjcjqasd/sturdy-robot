package com.atguigu.crud.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.ShoppingCart;
import com.atguigu.crud.dao.UserLoginMapper;
import com.atguigu.crud.service.GoodsService;
import com.atguigu.crud.service.SalesService;
import com.atguigu.crud.service.UserLoginService;
import com.atguigu.crud.test.GoodsService2;
import com.atguigu.crud.utils.WebUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class GoodsController
{
	@Autowired
	GoodsService goodsService;

	@Autowired
	GoodsService2 goodsService2;

	@Autowired
	UserLoginService userLoginService;

	@Autowired
	SalesService salesService;

	/**
	 * 修改商品信息
	 * 
	 * @param goods
	 * @param goodsid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/edit_publish", method = RequestMethod.POST)
	public Msg edit_publish(Goods goods, Integer goodsid)
	{
		goods.setImg("/static/images/" + goods.getImg());
		goodsService.edit_goods(goodsid, goods);
		return Msg.success();
	}

	@ResponseBody
	@RequestMapping(value = "/getGoods", method = RequestMethod.GET)
	public Msg getGoods(Integer goodsid)
	{
		Goods good = goodsService.getGood(goodsid);
		return Msg.success().add("good", good);
	}

	/**
	 * 批量删除
	 * 
	 * @return
	 */
	@RequestMapping(value = "/delPublish_all", method = RequestMethod.DELETE)
	@ResponseBody
	public Msg delPublish_all(String del_idstr)
	{
		List<Integer> del_ids = new ArrayList<>();
		String[] str_ids = del_idstr.split("-");

		// 组装id的集合
		for (String string : str_ids)
		{
			String trim = string.trim();
			goodsService.delByGoodsid(trim);
		}
		// 再删除sales表中数据
		for (String string : str_ids)
		{
			String trim = string.trim();
			salesService.delByGoodsid(trim);
		}
		return Msg.success();
	}

	/**
	 * 根据商品id删除sales表中数据,同时删除goods表中商品数据
	 * 
	 * @return
	 */
	@Transactional
	@RequestMapping(value = "delPublish", method = RequestMethod.DELETE)
	@ResponseBody
	public Msg delPublish(Integer goodsid)
	{
		salesService.delByGoodsid(goodsid);

		goodsService.delByGoodsid(goodsid);
		return Msg.success();
	}

	/**
	 * 根据username查询出用户发布的商品
	 * 
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/getPublish", method = RequestMethod.GET)
	public Msg getPublish(String username, HttpSession session)
	{
		// 1.根据username查询出用户的id
		Integer id = userLoginService.getId(username);
		// 根据id查询出多条发布记录中的goodsid的集合
		List<Integer> goodsids = salesService.getGoods(id);

		// 根据多个goodsid查询出goods的集合
		List<Goods> goodsList = goodsService.getGoodsByGoodsids(goodsids);

		session.setAttribute("goodsList", goodsList);
		return Msg.success();
	}

	/**
	 * 发布商品
	 * 
	 * @param goods
	 * @param img
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/publish", method = RequestMethod.POST)
	public Msg publish(Goods goods, String username)
	{
		goods.setImg("/static/images/" + goods.getImg());
		goods.setSalesamount(0);

		// 1 插入商品并返回商品id
		Integer goodsid = goodsService2.savePublish(goods);

		// 2 根据username查出用户id
		Integer id = userLoginService.getId(username);

		// 3 将goodsid和用户id插入到sales表
		salesService.insert(id, goodsid);
		return Msg.success();
	}

	/**
	 * 更改商品数量
	 */
	@ResponseBody
	@RequestMapping("/updateItemQuantity")
	public Msg updateItemQuantity(Integer goodid, Integer quantityVal, HttpSession session)
	{
		// 获取购物车更改数量
		ShoppingCart sc = WebUtils.getShoppingCart(session);
		goodsService.updateItemQuantity(sc, goodid, quantityVal);

		return Msg.success();
	}

	/**
	 * 批量删除
	 * 
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/remove_all/{del_idstr}", method = RequestMethod.DELETE)
	public Msg removeBatch(@PathVariable("del_idstr") String del_idstr, HttpSession session)
	{
		List<Integer> del_ids = new ArrayList<>();
		String[] str_ids = del_idstr.split("-");
		// 组装id的集合
		for (String string : str_ids)
		{
			del_ids.add(Integer.parseInt(string));
		}

		// 遍历id的集合
		for (Integer del_id : del_ids)
		{
			// 获取到购物车
			ShoppingCart sc = WebUtils.getShoppingCart(session);
			goodsService.removeItemFromShoppingCart(sc, del_id);
		}
		return Msg.success();
	}

	/**
	 * 删除单一购物项
	 * 
	 * @param ids
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/remove/{goodid}", method = RequestMethod.DELETE)
	public Msg deleteGood(@PathVariable("goodid") Integer goodid, HttpSession session)
	{
		// 1.获取购物车对象
		ShoppingCart sc = WebUtils.getShoppingCart(session);
		// 2.删除购物项
		goodsService.removeItemFromShoppingCart(sc, goodid);
		return Msg.success();
	}

	/**
	 * 添加到购物车
	 * 
	 * @param goodid
	 * @return
	 */
	@RequestMapping("/addToCart/{goodid}")
	public Msg addToCart(@PathVariable("goodid") Integer goodid, HttpSession session)
	{
		// 1.获取购物车对象
		ShoppingCart sc = WebUtils.getShoppingCart(session);
		// 2.调用Service的addToCart（）加入到购物车
		goodsService.addToCart(goodid, sc);
		return Msg.success();
	}

	/**
	 * 查询单一商品并返回到详情页面
	 * 
	 * @return
	 */
	@RequestMapping("/introduction")
	public String getGoodToIntroduction(@RequestParam("goodid") Integer goodid, Model model)
	{
		Goods good = goodsService.getGood(goodid);
		// System.out.println(good.getSalesamount());
		model.addAttribute("good", good);
		return "forward:/introduction.jsp";
	}

	/**
	 * 查询出重要商品(分页查询)
	 * 
	 * @param pn
	 * @return
	 */
	@RequestMapping("/goods_imp")
	@ResponseBody
	public Msg goods_imp(Integer pn, HttpSession session)
	{
		PageHelper.startPage(pn, 5);
		List<Goods> goods = goodsService.getImpGoods();
		PageInfo page = new PageInfo(goods, 3);
		session.setAttribute("PageInfo", page);
		return Msg.success().add("PageInfo", page);
	}

	/**
	 * 根据类型查询商品数据（分页查询）
	 * 
	 * @return
	 */
	@RequestMapping("/goods")
	@ResponseBody
	public Msg getGoods(Integer pn, String type, Integer sales, Integer pricea, Integer priced)
	{
		// System.out.println(sales);
		List<Goods> goods = null;
		PageHelper.startPage(pn, 8);
		if (sales == 1)
		{
			goods = goodsService.getGoodsBySales(type);
		} else if (pricea == 1)
		{
			goods = goodsService.getGoodsByPricea(type);
		} else if (priced == 1)
		{
			goods = goodsService.getGoodsByPriced(type);
		} else
		{
			goods = goodsService.getGoodsByType(type);
		}
		PageInfo page = new PageInfo(goods, 5);
		return Msg.success().add("PageInfo", page);
	}

	@RequestMapping("/goods2")
	public String getGoods2(Integer pn, String type, Model model, Integer sales, Integer pricea, Integer priced)
	{
		List<Goods> goods = null;
		PageHelper.startPage(pn, 8);
		if (sales == 1)
		{
			goods = goodsService.getGoodsBySales(type);
		} else if (pricea == 1)
		{
			goods = goodsService.getGoodsByPricea(type);
		} else if (priced == 1)
		{
			goods = goodsService.getGoodsByPriced(type);
		} else
		{
			goods = goodsService.getGoodsByType(type);
		}
		PageInfo page = new PageInfo(goods, 5);
		model.addAttribute(page);
		return "forward:/search.jsp";
	}
}
