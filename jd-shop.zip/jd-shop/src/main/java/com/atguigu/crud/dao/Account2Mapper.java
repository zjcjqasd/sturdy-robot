package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Account2;
import com.atguigu.crud.bean.Account2Example;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface Account2Mapper {
    long countByExample(Account2Example example);

    int deleteByExample(Account2Example example);

    int deleteByPrimaryKey(String username);

    int insert(Account2 record);

    int insertSelective(Account2 record);

    List<Account2> selectByExample(Account2Example example);

    Account2 selectByPrimaryKey(String username);

    int updateByExampleSelective(@Param("record") Account2 record, @Param("example") Account2Example example);

    int updateByExample(@Param("record") Account2 record, @Param("example") Account2Example example);

    int updateByPrimaryKeySelective(Account2 record);

    int updateByPrimaryKey(Account2 record);
}