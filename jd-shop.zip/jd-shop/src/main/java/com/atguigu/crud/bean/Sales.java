package com.atguigu.crud.bean;

public class Sales {
    public Sales()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	private Integer salesid;

    private Integer goodsid;

    private Integer id;

    public Integer getSalesid() {
        return salesid;
    }

    public Sales(Integer salesid, Integer goodsid, Integer id)
	{
		super();
		this.salesid = salesid;
		this.goodsid = goodsid;
		this.id = id;
	}

	public void setSalesid(Integer salesid) {
        this.salesid = salesid;
    }

    public Integer getGoodsid() {
        return goodsid;
    }

    public void setGoodsid(Integer goodsid) {
        this.goodsid = goodsid;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}