package com.atguigu.crud.bean;

public class Goods {
    private Integer goodsid;

    private String name;

    private Float price;

    private Integer salesamount;

    private Integer storenumber;

    private String remark;

    private String type;

    private String img;

    private Integer important;

    private Integer news;

    public Goods(Integer goodsid, String name, Float price, Integer salesamount, Integer storenumber, String remark,
			String type, String img, Integer important, Integer news)
	{
		super();
		this.goodsid = goodsid;
		this.name = name;
		this.price = price;
		this.salesamount = salesamount;
		this.storenumber = storenumber;
		this.remark = remark;
		this.type = type;
		this.img = img;
		this.important = important;
		this.news = news;
	}

	public Goods(Integer goodsid, String name, Float price, Integer salesamount, Integer storenumber, String remark)
	{
		super();
		this.goodsid = goodsid;
		this.name = name;
		this.price = price;
		this.salesamount = salesamount;
		this.storenumber = storenumber;
		this.remark = remark;
	}

	public Goods()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getGoodsid() {
        return goodsid;
    }

    public void setGoodsid(Integer goodsid) {
        this.goodsid = goodsid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Integer getSalesamount() {
        return salesamount;
    }

    public void setSalesamount(Integer salesamount) {
        this.salesamount = salesamount;
    }

    public Integer getStorenumber() {
        return storenumber;
    }

    public void setStorenumber(Integer storenumber) {
        this.storenumber = storenumber;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img == null ? null : img.trim();
    }

    public Integer getImportant() {
        return important;
    }

    public void setImportant(Integer important) {
        this.important = important;
    }

    public Integer getNews() {
        return news;
    }

    public void setNews(Integer news) {
        this.news = news;
    }
}